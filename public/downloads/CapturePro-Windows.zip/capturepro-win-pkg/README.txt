Double-click CapturePro-Launch.bat to open CapturePro in a dedicated desktop window without browser tabs or address bars.
