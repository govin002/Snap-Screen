@echo off
title CapturePro PC — Product by Gowin
color 0F

echo ===================================================================
echo           CapturePro PC - Screen Recorder ^& Snipping Studio
echo                         Product by Gowin
echo ===================================================================
echo.

set "SCRIPT_DIR=%~dp0"
set "DESKTOP_DIR=%USERPROFILE%\Desktop"
set "SHORTCUT_PATH=%DESKTOP_DIR%\CapturePro PC.lnk"

:: Check if desktop shortcut already exists. If not, prompt the user!
if not exist "%SHORTCUT_PATH%" (
    echo [Setup] Desktop shortcut not detected.
    set /p ASK_SHORTCUT="Would you like to create a Desktop Shortcut? (Y/N, default is Y): "
    if "%ASK_SHORTCUT%"=="" set ASK_SHORTCUT=Y
    if /i "%ASK_SHORTCUT%"=="Y" (
        cscript //nologo "%SCRIPT_DIR%Create-Desktop-Shortcut.vbs" /silent
        echo [OK] Desktop shortcut created with custom icon! (Product by Gowin)
        echo.
    )
)

echo Starting CapturePro PC Desktop Window...
set "APP_URL=https://ais-dev-gq4drhi4etgfns74tlwr5v-22416287859.asia-east1.run.app"

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%APP_URL%"
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%APP_URL%"
    exit /b
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%APP_URL%"
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%APP_URL%"
    exit /b
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="%APP_URL%"
    exit /b
)

:: Fallback default browser
start "" "%APP_URL%"
