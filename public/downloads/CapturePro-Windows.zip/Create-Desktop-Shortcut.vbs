Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\CapturePro PC.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "https://ais-dev-gq4drhi4etgfns74tlwr5v-22416287859.asia-east1.run.app"
oLink.Description = "CapturePro PC - Screen Recorder & Snipping Studio"
oLink.Save
MsgBox "CapturePro PC desktop shortcut created successfully on your desktop!", vbInformation, "CapturePro PC"
