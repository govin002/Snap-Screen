' CapturePro PC — Product by Gowin
Set oWS = WScript.CreateObject("WScript.Shell")
sDesktop = oWS.SpecialFolders("Desktop")
sScriptDir = oWS.CurrentDirectory

' Check if run with /silent flag
bSilent = False
If WScript.Arguments.Count > 0 Then
    If LCase(WScript.Arguments(0)) = "/silent" Then bSilent = True
End If

bCreate = True
If Not bSilent Then
    nAnswer = MsgBox("Would you like to create a Desktop Shortcut for CapturePro PC?" & vbCrLf & vbCrLf & "Product by Gowin", vbYesNo + vbQuestion, "CapturePro PC — Product by Gowin")
    If nAnswer <> vbYes Then bCreate = False
End If

If bCreate Then
    sLinkFile = sDesktop & "\CapturePro PC.lnk"
    Set oLink = oWS.CreateShortcut(sLinkFile)
    oLink.TargetPath = sScriptDir & "\Launch-CapturePro.bat"
    oLink.WorkingDirectory = sScriptDir
    oLink.Description = "CapturePro PC - Screen Recorder & Snipping Studio (Product by Gowin)"
    oLink.IconLocation = sScriptDir & "\app.ico,0"
    oLink.Save
    
    If Not bSilent Then
        MsgBox "Desktop shortcut created successfully with custom icon!" & vbCrLf & vbCrLf & "Product by Gowin", vbInformation, "CapturePro PC"
    End If
End If
