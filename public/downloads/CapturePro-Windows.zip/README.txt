=====================================================
CapturePro PC — Windows Desktop Launcher
=====================================================

HOW TO RUN:
1. Double-click "Launch-CapturePro.bat" to open CapturePro in a dedicated desktop window without browser bars.
   OR
2. Double-click "CapturePro PC.url" to launch immediately.

HOW TO ADD TO DESKTOP:
- Double-click "Create-Desktop-Shortcut.vbs" to place an icon on your Windows Desktop.

NO INSTALLATION REQUIRED!
Runs with zero setup.
