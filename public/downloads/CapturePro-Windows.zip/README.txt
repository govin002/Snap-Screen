=================================================================
CapturePro PC — Screen Recorder & Snipping Studio
Product by Gowin
=================================================================

FEATURES & HOW TO RUN:
1. Double-click "Launch-CapturePro.bat"
   - It will ask if you want to create a desktop shortcut (with the custom icon).
   - Launches the app in a clean, standalone desktop window.

2. Double-click "Create-Desktop-Shortcut.vbs"
   - Asks: "Would you like to create a Desktop Shortcut for CapturePro PC?"
   - Creates the official desktop shortcut on your Windows desktop using app.ico.

3. "app.ico":
   - The custom multi-resolution application icon.

Product by Gowin. Free & Open Source.
