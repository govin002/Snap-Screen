#!/bin/bash
# CapturePro PC — Product by Gowin
APP_URL="https://ais-dev-gq4drhi4etgfns74tlwr5v-22416287859.asia-east1.run.app"

for browser in google-chrome google-chrome-stable chromium-browser chromium brave-browser microsoft-edge-stable msedge; do
  if command -v "$browser" >/dev/null 2>&1; then
    exec "$browser" --app="$APP_URL" --class="CapturePro" --name="CapturePro" "$@"
  fi
done

if command -v xdg-open >/dev/null 2>&1; then
  exec xdg-open "$APP_URL"
elif command -v sensible-browser >/dev/null 2>&1; then
  exec sensible-browser "$APP_URL"
elif command -v x-www-browser >/dev/null 2>&1; then
  exec x-www-browser "$APP_URL"
elif command -v firefox >/dev/null 2>&1; then
  exec firefox --new-window "$APP_URL" "$@"
fi
