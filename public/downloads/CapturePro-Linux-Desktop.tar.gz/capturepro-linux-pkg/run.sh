#!/bin/bash
# CapturePro PC Desktop Launcher
APP_URL="https://ais-dev-gq4drhi4etgfns74tlwr5v-22416287859.asia-east1.run.app"

for browser in google-chrome chromium-browser chromium brave-browser msedge firefox; do
  if command -v "$browser" >/dev/null 2>&1; then
    if [ "$browser" = "firefox" ]; then
      exec "$browser" --new-window "$APP_URL" "$@"
    else
      exec "$browser" --app="$APP_URL" --class="CapturePro" --name="CapturePro" "$@"
    fi
  fi
done

xdg-open "$APP_URL"
