# CapturePro PC — Release Version 1.0.0 (v1.0.0)

## Included Release Packages:
1. CapturePro_1.0.0_amd64.deb: Native Debian/Ubuntu/Mint installer package
2. CapturePro-Linux-Desktop.tar.gz: Universal Linux desktop launcher with .desktop entry
3. CapturePro-Windows.zip: Standalone Windows desktop launcher
4. install-linux.sh: 1-click Linux desktop menu installer

## Features in v1.0.0:
- Hardware-accelerated 4K & 1080p Screen Recording at 60 FPS
- Webcam Picture-in-Picture with customizable shapes (circle, rounded, square)
- Dual Audio Mixing (System PC audio + Microphone with echo cancellation)
- Snipping Studio with Arrow, Box, Oval, Pen, Highlighter, and Step badges (1, 2, 3...)
- Sensitive Data Redaction Blur / Pixelation mosaic tool
- 2x Magnifier Loupe lens
- Dual-slider video trim studio and audio WAV extraction
- Floating presenter teleprompter
