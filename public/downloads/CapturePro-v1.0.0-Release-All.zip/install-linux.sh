#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="$HOME/.local/share/applications"
mkdir -p "$TARGET_DIR"

sed "s|CURRENT_DIR|$DIR|g" "$DIR/capturepro.desktop" > "$TARGET_DIR/capturepro.desktop"
chmod +x "$TARGET_DIR/capturepro.desktop"
chmod +x "$DIR/run.sh"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$TARGET_DIR" || true
fi

echo "========================================================"
echo " CapturePro PC installed successfully to your Linux desktop!"
echo " Look for 'CapturePro PC' in your application menu."
echo "========================================================"
