#!/bin/bash
# CapturePro PC Installer — Product by Gowin
echo "=========================================================="
echo "   CapturePro PC Installer — Product by Gowin"
echo "=========================================================="
DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="$HOME/.local/share/applications"
mkdir -p "$TARGET_DIR"

sed "s|CURRENT_DIR|$DIR|g" "$DIR/capturepro.desktop" > "$TARGET_DIR/capturepro.desktop"
chmod +x "$TARGET_DIR/capturepro.desktop"
chmod +x "$DIR/run.sh"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$TARGET_DIR" || true
fi

echo "[OK] Installed to application menu!"

# Ask user if they want a shortcut on their Linux Desktop
read -p "Would you like to add a shortcut to your Linux Desktop? (y/n, default y): " ASK_DESKTOP
ASK_DESKTOP=${ASK_DESKTOP:-y}
if [ "$ASK_DESKTOP" = "y" ] || [ "$ASK_DESKTOP" = "Y" ]; then
    if [ -d "$HOME/Desktop" ]; then
        cp "$TARGET_DIR/capturepro.desktop" "$HOME/Desktop/"
        chmod +x "$HOME/Desktop/capturepro.desktop"
        echo "[OK] Shortcut created on ~/Desktop with custom icon!"
    fi
fi

echo "=========================================================="
echo " CapturePro PC is ready to use! (Product by Gowin)"
echo "=========================================================="
